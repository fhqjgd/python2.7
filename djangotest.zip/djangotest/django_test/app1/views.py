# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse
from dwebsocket import accept_websocket ,require_websocket
import os ,sys ,re ,time ,sys ,subprocess
reload(sys)
sys.setdefaultencoding('gbk')

#
#def ceshilog(request):#
#    import paramiko
#    b = []
#    s = paramiko.SSHClient()
#    s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
#    s.connect('192.168.1.192', 22, 'tomcat', 'tomcat')
#    stdin, stdout, stderr = s.exec_command('tail -n 50  /usr/local/tomcat_front/logs/catalina.out')
#    for i in stdout.readlines():
#        i = i
#        b.append(i)
#    s.close()
#    return render(request, 'testenv.html' ,{'b': b})
#
#def yfblog(request):
#    import paramiko
#    b = []
#    s = paramiko.SSHClient()
#    s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
#    s.connect('192.168.1.222', 22, 'tomcat', 'tomcat')
#    stdin, stdout, stderr = s.exec_command('tail -n 50  /usr/local/tomcat_front/logs/catalina.out')
#    for i in stdout.readlines():
#        i = i
#        b.append(i)
#    s.close()
#    return render(request, 'preenv.html' ,{'b': b})

def index(request):
    return render(request, 'index.html')#

def uploadFile1(request):
    import paramiko
    if request.method == "POST":
        myFile = request.FILES.get("myfile", None)
        if not myFile:
            return HttpResponse("no files for upload!")
        destination = open(os.path.join("D:\\jpg", myFile.name), 'wb+')
        for chunk in myFile.chunks():
            destination.write(chunk)
        destination.close()
        try:
            t = paramiko.Transport(('192.168.1.192', 22))
            t.connect(username='tomcat', password='tomcat')
            sftp = paramiko.SFTPClient.from_transport(t)
            sftp.put('D:\\jpg' %myFile.name  ,'/tmp/auto/%s' %myFile.name )
            t.close()
            return render(request, 'uploadtip.html')
        except Exception, e:
            return HttpResponse(e)
def autofront(request):
    l = []
    import paramiko
    a = time.strftime('%Y%m%d%mm', time.localtime(time.time()))
    b = '/webapps/hlwl_front/' + str(a) + '.tar.gz'
    try:
        s = paramiko.SSHClient()
        s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        s.connect('192.168.1.192', 22, 'tomcat', 'tomcat')
        stdin, stdout, stderr = s.exec_command('/tmp/auto/auto1.sh')
    except Exception, e:
        return HttpResponse(e)
    return render(request, 'baktip.html' ,{'b' : b})



@require_websocket
def ws(request):
    message = request.websocketr.read('b')
    request.websocket.send(message)

def hehe(request):
    return render(request, 'websocket.html')
